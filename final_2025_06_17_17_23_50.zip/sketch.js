let score = 0;
let coins = 0;
let pointsPerClick = 1;
let upgradeLevel = 0;
let upgradeCost = 5;
let cursors = 0;
let cursorCost = 20;
let cursorInterval = 1000; // ms
let lastCursorTime = 0;

// Variáveis para o fertilizante
let fertilizerLevel = 0;
let fertilizerCost = 50;

// Variáveis para a fábrica de ketchup
let ketchupFactoryLevel = 0;
let ketchupFactoryCost = 200;
let ketchupFactoryBonus = 0; // bônus de pontos por segundo

// Habilidades
let activeAbilityCost = 500;
let activeAbilityActive = false;
let activeAbilityStartTime = 0;
let activeAbilityDuration = 10000; // 10 segundos em ms
let pointsPerClickBonus = 0;

// Merenda Escolar
let schoolMealAbilityCost = 1000;
let schoolMealAbilityActive = false;
let schoolMealAbilityStartTime = 0;
let schoolMealAbilityDuration = 30000; // 30 segundos
let schoolMealProductionBonus = 0;

// Rebirth
let rebirthCount = 0;
let rebirthRequirement = 100000;
let rebirthBonus = 0;
let rebirthButtonW = 200;
let rebirthButtonH = 50;
let rebirthButtonX, rebirthButtonY;

// Variáveis para pontos por segundo (PPS)
let lastScore = 0;
let pps = 0;
let lastPpsUpdate = 0;

let buttonX, buttonY, buttonW, buttonH;
let sellButtonX, sellButtonY, sellButtonW, sellButtonH;
let sellAllButtonX, sellAllButtonY, sellAllButtonW, sellAllButtonH;
let activeAbilityButtonX, activeAbilityButtonY, activeAbilityButtonW, activeAbilityButtonH;

let currentPage = "game"; // "game", "upgrades", "abilities"
let upgradesButtonX, upgradesButtonY, upgradesButtonW, upgradesButtonH;
let abilitiesButtonX, abilitiesButtonY, abilitiesButtonW, abilitiesButtonH;
let backButtonX, backButtonY, backButtonW, backButtonH;
let backAbilitiesButtonX, backAbilitiesButtonY, backAbilitiesButtonW, backAbilitiesButtonH;

// Para upgrades page
let upgradeButtonX, upgradeButtonY, upgradeButtonW, upgradeButtonH;
let cursorButtonX, cursorButtonY, cursorButtonW, cursorButtonH;
let fertilizerButtonX, fertilizerButtonY, fertilizerButtonW, fertilizerButtonH;
let ketchupFactoryButtonX, ketchupFactoryButtonY, ketchupFactoryButtonW, ketchupFactoryButtonH;

function setup() {
  createCanvas(900, 700);
  buttonW = 120;
  buttonH = 120;
  buttonX = width / 2 - buttonW / 2;
  buttonY = height / 2 - buttonH / 2 - 60;
  textAlign(CENTER, CENTER);
  textSize(32);

  // Botão de vender pontos
  sellButtonW = 160;
  sellButtonH = 50;
  sellButtonX = width / 2 - sellButtonW / 2;
  sellButtonY = height - 120;

  // Botão de vender todos os pontos
  sellAllButtonW = 160;
  sellAllButtonH = 50;
  sellAllButtonX = width / 2 - sellAllButtonW / 2;
  sellAllButtonY = sellButtonY + sellButtonH + 15;

  // Botão para upgrades (NA LATERAL ESQUERDA)
  upgradesButtonW = 160;
  upgradesButtonH = 40;
  upgradesButtonX = 40;
  upgradesButtonY = 180;

  // Botão de habilidades (NA LATERAL ESQUERDA, embaixo do upgrades)
  abilitiesButtonW = 160;
  abilitiesButtonH = 40;
  abilitiesButtonX = 40;
  abilitiesButtonY = upgradesButtonY + upgradesButtonH + 20;

  // Botão de voltar (na tela de upgrades)
  backButtonW = 120;
  backButtonH = 40;
  backButtonX = 20;
  backButtonY = 20;

  // Botão de voltar (na tela de habilidades)
  backAbilitiesButtonW = 120;
  backAbilitiesButtonH = 40;
  backAbilitiesButtonX = 20;
  backAbilitiesButtonY = 20;

  // Organize os botões na tela de upgrades verticalmente, centralizados
  let upgBaseY = 160;
  let upgSpacing = 70;

  upgradeButtonW = 320;
  upgradeButtonH = 55;
  upgradeButtonX = width / 2 - upgradeButtonW / 2;
  upgradeButtonY = upgBaseY;

  cursorButtonW = 320;
  cursorButtonH = 55;
  cursorButtonX = width / 2 - cursorButtonW / 2;
  cursorButtonY = upgBaseY + upgSpacing;

  fertilizerButtonW = 320;
  fertilizerButtonH = 55;
  fertilizerButtonX = width / 2 - fertilizerButtonW / 2;
  fertilizerButtonY = upgBaseY + upgSpacing * 2;

  ketchupFactoryButtonW = 320;
  ketchupFactoryButtonH = 55;
  ketchupFactoryButtonX = width / 2 - ketchupFactoryButtonW / 2;
  ketchupFactoryButtonY = upgBaseY + upgSpacing * 3;

  // Botão habilidade ativa (Agricultura Familiar) para abilities page
  activeAbilityButtonW = 260;
  activeAbilityButtonH = 50;
  activeAbilityButtonX = width / 2 - activeAbilityButtonW / 2;
  activeAbilityButtonY = 175;

  // Inicializa contador PPS
  lastScore = score;
  lastPpsUpdate = millis();
}

function draw() {
  background(220);

  // Atualiza a posição do botão de rebirth no canto inferior direito
  rebirthButtonX = width - rebirthButtonW - 40;
  rebirthButtonY = height - rebirthButtonH - 40;

  // Habilidade Merenda Escolar: checa fim e aplica bônus
  handleSchoolMealAbility();

  // Atualiza pontos por segundo a cada 1s, nunca permitindo valor negativo
  if (millis() - lastPpsUpdate >= 1000) {
    pps = score - lastScore;
    if (pps < 0) pps = 0;
    lastScore = score;
    lastPpsUpdate = millis();
  }

  // Fábrica de ketchup: gera pontos automaticamente (com bônus se ativo)
  let ketchupBonus = getEffectiveKetchupBonus();
  if (ketchupFactoryLevel > 0) {
    ketchupFactoryBonus += ketchupBonus * (deltaTime / 1000);
    if (ketchupFactoryBonus >= 1) {
      let pointsToAdd = Math.floor(ketchupFactoryBonus);
      score += pointsToAdd;
      ketchupFactoryBonus -= pointsToAdd;
    }
  }

  // Checa fim da habilidade ativa Agricultura Familiar
  if (activeAbilityActive && millis() - activeAbilityStartTime > activeAbilityDuration) {
    activeAbilityActive = false;
    pointsPerClickBonus = 0;
  }

  if (currentPage === "game") {
    drawGamePage();
  } else if (currentPage === "upgrades") {
    drawUpgradePage();
  } else if (currentPage === "abilities") {
    drawAbilitiesPage();
  }
}

function drawRebirth() {
  // Exibe o contador de rebirth e bônus no topo direito
  fill(0);
  textSize(17);
  textAlign(RIGHT, CENTER);
  text("Renascimentos: " + rebirthCount, width - 50, 22);
  text("Bônus Rebirth: +" + (rebirthCount * 10) + "%", width - 50, 45);
  textAlign(CENTER, CENTER);

  // Desenha o botão
  if (score >= rebirthRequirement) {
    fill('#bb00ff');
  } else {
    fill('#bbb');
  }
  rect(rebirthButtonX, rebirthButtonY, rebirthButtonW, rebirthButtonH, 12);
  fill(255);
  textSize(17);
  text("Renascimento!", rebirthButtonX + rebirthButtonW / 2, rebirthButtonY + rebirthButtonH / 2);

  // Texto do requisito
  fill(0);
  textSize(13);
  text(
    "Precisa de " + rebirthRequirement + " pontos para renascer",
    rebirthButtonX + rebirthButtonW / 2,
    rebirthButtonY + rebirthButtonH + 13
  );
}

function doRebirth() {
  if (score >= rebirthRequirement) {
    rebirthCount += 1;
    rebirthBonus = rebirthCount * 0.10; // 10% bônus de produção por rebirth
    // Reseta tudo exceto rebirths
    score = 0;
    coins = 0;
    pointsPerClick = 1;
    upgradeLevel = 0;
    upgradeCost = 5;
    cursors = 0;
    cursorCost = 20;
    fertilizerLevel = 0;
    fertilizerCost = 50;
    ketchupFactoryLevel = 0;
    ketchupFactoryCost = 200;
    ketchupFactoryBonus = 0;
    activeAbilityActive = false;
    pointsPerClickBonus = 0;
    schoolMealAbilityActive = false;
    schoolMealProductionBonus = 0;
    // Dificuldade aumenta: próximo rebirth precisa de mais pontos
    rebirthRequirement = Math.floor(rebirthRequirement * 2.5);
  }
}

function handleSchoolMealAbility() {
  if (schoolMealAbilityActive) {
    if (millis() - schoolMealAbilityStartTime > schoolMealAbilityDuration) {
      schoolMealAbilityActive = false;
      schoolMealProductionBonus = 0;
    }
  }
}

function getEffectivePointsPerClick() {
  let base = pointsPerClick + pointsPerClickBonus;
  let bonus = 1 + rebirthBonus;
  if (schoolMealAbilityActive) bonus *= 2;
  return base * bonus;
}
function getEffectiveCursorPoints() {
  let base = cursors * pointsPerClick;
  let bonus = 1 + rebirthBonus;
  if (schoolMealAbilityActive) bonus *= 2;
  return base * bonus;
}
function getEffectiveKetchupBonus() {
  let base = ketchupFactoryLevel * 5;
  let bonus = 1 + rebirthBonus;
  if (schoolMealAbilityActive) bonus *= 2;
  return base * bonus;
}

function drawGamePage() {
  // Desenhar tomate
  drawTomato(buttonX + buttonW / 2, buttonY + buttonH / 2, buttonW, buttonH);

  // Pontuação
  fill(0);
  textSize(32);
  text('Pontos: ' + score, width / 2, 50);

  // Moedas
  textSize(22);
  text('Moedas: ' + coins, width / 2, 90);

  // Pontos por clique
  textSize(20);
  let effectivePointsPerClick = getEffectivePointsPerClick();
  if (activeAbilityActive && schoolMealAbilityActive) {
    fill('#29a329');
    text('Pontos por clique: ' + effectivePointsPerClick + ' (x4!)', width / 2, 120);
  } else if (activeAbilityActive || schoolMealAbilityActive) {
    fill('#29a329');
    text('Pontos por clique: ' + effectivePointsPerClick + ' (x2!)', width / 2, 120);
  } else {
    fill(0);
    text('Pontos por clique: ' + pointsPerClick, width / 2, 120);
  }

  // Cursores info
  textSize(18);
  fill(0);
  text('Cursores automáticos: ' + cursors, width / 2, 150);

  // Pontos por segundo
  textSize(18);
  fill(40, 100, 180);
  text('Pontos por segundo: ' + pps, width / 2, 180);

  // Botão de upgrades (lado esquerdo)
  fill("#0084ff");
  rect(upgradesButtonX, upgradesButtonY, upgradesButtonW, upgradesButtonH, 10);
  fill(255);
  textSize(22);
  text("Upgrades", upgradesButtonX + upgradesButtonW / 2, upgradesButtonY + upgradesButtonH / 2);

  // Botão de habilidades (lado esquerdo)
  fill("#6a30a6");
  rect(abilitiesButtonX, abilitiesButtonY, abilitiesButtonW, abilitiesButtonH, 10);
  fill(255);
  textSize(22);
  text("Habilidades", abilitiesButtonX + abilitiesButtonW / 2, abilitiesButtonY + abilitiesButtonH / 2);

  // Botão de vender pontos
  drawSellButton();

  // Botão de vender todos os pontos
  drawSellAllButton();

  // Cursores automáticos (com bônus se merenda escolar ativa)
  if (cursors > 0 && millis() - lastCursorTime > cursorInterval) {
    let cursorPoints = getEffectiveCursorPoints();
    score += cursorPoints;
    lastCursorTime = millis();
    // Efeito visual opcional: breve flash
    fill(255, 0, 0, 80);
    ellipse(buttonX + buttonW / 2, buttonY + buttonH / 2, buttonW + 10, buttonH + 10);
  }

  // Rebirth system (no canto inferior direito)
  drawRebirth();
}

function drawSellAllButton() {
  fill(score >= 10 ? '#FFB300' : '#ccc');
  rect(sellAllButtonX, sellAllButtonY, sellAllButtonW, sellAllButtonH, 12);
  fill(0);
  textSize(13);
  text('Vender TODOS pontos', width / 2, sellAllButtonY + sellAllButtonH / 2);
}

function sellAllPoints() {
  if (score >= 10) {
    let bundles = Math.floor(score / 10);
    score -= bundles * 10;
    coins += bundles;
  }
}

function drawAbilitiesPage() {
  fill(0);
  textSize(34);
  text("Habilidades", width / 2, 60);

  textSize(22);
  fill(50);
  text("Moedas: " + coins, width / 2, 110);

  // Caixa visual para habilidades
  fill(240);
  stroke(180);
  rect(width / 2 - 180, 145, 360, 180, 18);
  noStroke();

  // Botão de habilidade ativa (Agricultura Familiar)
  drawActiveAbilityButton();

  // Botão de habilidade ativa (Merenda Escolar)
  drawSchoolMealAbilityButton();

  // Botão de voltar
  fill("#FF6666");
  rect(backAbilitiesButtonX, backAbilitiesButtonY, backAbilitiesButtonW, backAbilitiesButtonH, 10);
  fill(255);
  textSize(20);
  text("Voltar", backAbilitiesButtonX + backAbilitiesButtonW / 2, backAbilitiesButtonY + backAbilitiesButtonH / 2);

  // Timer da habilidade ativa Agricultura Familiar
  if (activeAbilityActive) {
    let left = ((activeAbilityDuration - (millis() - activeAbilityStartTime)) / 1000).toFixed(1);
    fill('#29a329');
    textSize(24);
    text('Agricultura Familiar ativa! (' + left + 's)', width / 2, 350);
  }

  // Timer da habilidade ativa Merenda Escolar
  if (schoolMealAbilityActive) {
    let left = ((schoolMealAbilityDuration - (millis() - schoolMealAbilityStartTime)) / 1000).toFixed(1);
    fill('#e07a13');
    textSize(24);
    text('Merenda Escolar ativa! (' + left + 's)', width / 2, 380);
  }
}

function drawActiveAbilityButton() {
  let canUse = coins >= activeAbilityCost && !activeAbilityActive;
  fill(canUse ? '#29a329' : '#888');
  rect(activeAbilityButtonX, activeAbilityButtonY, activeAbilityButtonW, activeAbilityButtonH, 12);
  fill(0);
  textSize(13);
  if (activeAbilityActive) {
    text('Agricultura Familiar em uso!', width / 2, activeAbilityButtonY + activeAbilityButtonH / 2);
  } else {
    text('Agricultura Familiar (x2 por 10s) - 500 moedas', width / 2, activeAbilityButtonY + activeAbilityButtonH / 2);
  }
}

function drawSchoolMealAbilityButton() {
  let btnX = activeAbilityButtonX;
  let btnY = activeAbilityButtonY + activeAbilityButtonH + 15;
  let btnW = activeAbilityButtonW;
  let btnH = activeAbilityButtonH;

  let canUse = coins >= schoolMealAbilityCost && !schoolMealAbilityActive;
  fill(canUse ? '#e07a13' : '#888');
  rect(btnX, btnY, btnW, btnH, 12);
  fill(0);
  textSize(13);
  if (schoolMealAbilityActive) {
    text('Merenda Escolar em uso!', width / 2, btnY + btnH / 2);
  } else {
    text('Merenda Escolar (x2 produção, 30s) - 1000 moedas', width / 2, btnY + btnH / 2);
  }
}

function activateActiveAbility() {
  if (coins >= activeAbilityCost && !activeAbilityActive) {
    coins -= activeAbilityCost;
    activeAbilityActive = true;
    activeAbilityStartTime = millis();
    pointsPerClickBonus = pointsPerClick;
  }
}

function activateSchoolMealAbility() {
  if (coins >= schoolMealAbilityCost && !schoolMealAbilityActive) {
    coins -= schoolMealAbilityCost;
    schoolMealAbilityActive = true;
    schoolMealAbilityStartTime = millis();
    schoolMealProductionBonus = 1;
  }
}

function drawUpgradePage() {
  fill(0);
  textSize(34);
  text("Upgrades", width / 2, 60);

  textSize(22);
  fill(50);
  text("Moedas: " + coins, width / 2, 110);

  fill(240);
  stroke(180);
  rect(width/2-180, 145, 360, 320, 18);
  noStroke();

  drawUpgradeButton();
  drawCursorButton();
  drawFertilizerButton();
  drawKetchupFactoryButton();

  fill(70);
  textSize(17);
  textAlign(LEFT, CENTER);
  text('Pontos por clique: ' + pointsPerClick, width/2-160, 490);
  text('Cursores automáticos: ' + cursors, width/2-160, 520);
  text('Fertilizante: ' + fertilizerLevel, width/2+60, 490);
  text('Fábricas de Ketchup: ' + ketchupFactoryLevel, width/2+60, 520);
  textAlign(CENTER, CENTER);

  fill("#FF6666");
  rect(backButtonX, backButtonY, backButtonW, backButtonH, 10);
  fill(255);
  textSize(20);
  text("Voltar", backButtonX + backButtonW / 2, backButtonY + backButtonH / 2);
}

function mousePressed() {
  if (currentPage === "game") {
    let dx = mouseX - (buttonX + buttonW / 2);
    let dy = mouseY - (buttonY + buttonH / 2);
    let effectivePointsPerClick = getEffectivePointsPerClick();
    if ((dx * dx) / ((buttonW / 2) * (buttonW / 2)) + (dy * dy) / ((buttonH / 2) * (buttonH / 2)) <= 1) {
      score += effectivePointsPerClick;
      if (score < 0) score = 0;
    }

    if (
      mouseX >= abilitiesButtonX &&
      mouseX <= abilitiesButtonX + abilitiesButtonW &&
      mouseY >= abilitiesButtonY &&
      mouseY <= abilitiesButtonY + abilitiesButtonH
    ) {
      currentPage = "abilities";
    }

    if (
      mouseX >= sellButtonX &&
      mouseX <= sellButtonX + sellButtonW &&
      mouseY >= sellButtonY &&
      mouseY <= sellButtonY + sellButtonH
    ) {
      sellPoints();
    }

    if (
      mouseX >= sellAllButtonX &&
      mouseX <= sellAllButtonX + sellAllButtonW &&
      mouseY >= sellAllButtonY &&
      mouseY <= sellAllButtonY + sellAllButtonH
    ) {
      sellAllPoints();
    }

    if (
      mouseX >= upgradesButtonX &&
      mouseX <= upgradesButtonX + upgradesButtonW &&
      mouseY >= upgradesButtonY &&
      mouseY <= upgradesButtonY + upgradesButtonH
    ) {
      currentPage = "upgrades";
    }

    // Clique no botão de renascimento (rebirth) - canto inferior direito
    if (
      mouseX >= rebirthButtonX &&
      mouseX <= rebirthButtonX + rebirthButtonW &&
      mouseY >= rebirthButtonY &&
      mouseY <= rebirthButtonY + rebirthButtonH
    ) {
      doRebirth();
    }
  } else if (currentPage === "upgrades") {
    if (
      mouseX >= upgradeButtonX &&
      mouseX <= upgradeButtonX + upgradeButtonW &&
      mouseY >= upgradeButtonY &&
      mouseY <= upgradeButtonY + upgradeButtonH
    ) {
      buyUpgrade();
    }

    if (
      mouseX >= cursorButtonX &&
      mouseX <= cursorButtonX + cursorButtonW &&
      mouseY >= cursorButtonY &&
      mouseY <= cursorButtonY + cursorButtonH
    ) {
      buyCursor();
    }

    if (
      mouseX >= fertilizerButtonX &&
      mouseX <= fertilizerButtonX + fertilizerButtonW &&
      mouseY >= fertilizerButtonY &&
      mouseY <= fertilizerButtonY + fertilizerButtonH
    ) {
      buyFertilizer();
    }

    if (
      mouseX >= ketchupFactoryButtonX &&
      mouseX <= ketchupFactoryButtonX + ketchupFactoryButtonW &&
      mouseY >= ketchupFactoryButtonY &&
      mouseY <= ketchupFactoryButtonY + ketchupFactoryButtonH
    ) {
      buyKetchupFactory();
    }

    if (
      mouseX >= backButtonX &&
      mouseX <= backButtonX + backButtonW &&
      mouseY >= backButtonY &&
      mouseY <= backButtonY + backButtonH
    ) {
      currentPage = "game";
    }
  } else if (currentPage === "abilities") {
    if (
      mouseX >= activeAbilityButtonX &&
      mouseX <= activeAbilityButtonX + activeAbilityButtonW &&
      mouseY >= activeAbilityButtonY &&
      mouseY <= activeAbilityButtonY + activeAbilityButtonH
    ) {
      activateActiveAbility();
    }

    let schoolMealBtnY = activeAbilityButtonY + activeAbilityButtonH + 15;
    if (
      mouseX >= activeAbilityButtonX &&
      mouseX <= activeAbilityButtonX + activeAbilityButtonW &&
      mouseY >= schoolMealBtnY &&
      mouseY <= schoolMealBtnY + activeAbilityButtonH
    ) {
      activateSchoolMealAbility();
    }

    if (
      mouseX >= backAbilitiesButtonX &&
      mouseX <= backAbilitiesButtonX + backAbilitiesButtonW &&
      mouseY >= backAbilitiesButtonY &&
      mouseY <= backAbilitiesButtonY + backAbilitiesButtonH
    ) {
      currentPage = "game";
    }
  }
}

function drawTomato(x, y, w, h) {
  fill(230, 40, 40);
  ellipse(x, y, w, h);
  fill(255, 120, 120, 80);
  ellipse(x - w * 0.15, y - h * 0.15, w * 0.3, h * 0.22);
  fill(50, 180, 60);
  for (let i = 0; i < 5; i++) {
    let angle = PI / 2 + i * TWO_PI / 5;
    let leafX = x + cos(angle) * w * 0.25;
    let leafY = y - h * 0.45 + sin(angle) * h * 0.15;
    ellipse(leafX, leafY, w * 0.18, h * 0.18);
  }
  stroke(60, 110, 40);
  strokeWeight(4);
  line(x, y - h * 0.46, x, y - h * 0.6);
  noStroke();
}

function drawSellButton() {
  fill(score >= 10 ? '#FFB300' : '#ccc');
  rect(sellButtonX, sellButtonY, sellButtonW, sellButtonH, 12);
  fill(0);
  textSize(22);
  text('Vender 10 pontos', width / 2, sellButtonY + sellButtonH / 2);
}

function sellPoints() {
  if (score >= 10) {
    score -= 10;
    if (score < 0) score = 0;
    coins += 1;
  }
}

function drawUpgradeButton() {
  fill(coins >= upgradeCost ? '#9bc53d' : '#ccc');
  rect(upgradeButtonX, upgradeButtonY, upgradeButtonW, upgradeButtonH, 14);
  fill(0);
  textSize(17);
  text(
    'Melhoria (+1/click) | Nível: ' + upgradeLevel + ' | ' + upgradeCost + ' moedas',
    width / 2,
    upgradeButtonY + upgradeButtonH / 2
  );
}

function buyUpgrade() {
  if (coins >= upgradeCost) {
    coins -= upgradeCost;
    pointsPerClick += 1;
    upgradeLevel += 1;
    upgradeCost = Math.ceil(upgradeCost * 1.15);
  }
}

function drawCursorButton() {
  fill(coins >= cursorCost ? '#42a5f5' : '#ccc');
  rect(cursorButtonX, cursorButtonY, cursorButtonW, cursorButtonH, 14);
  fill(0);
  textSize(17);
  text(
    'Cursor Automático (+1 auto) | ' + cursorCost + ' moedas',
    width / 2,
    cursorButtonY + cursorButtonH / 2
  );
}

function buyCursor() {
  if (coins >= cursorCost) {
    coins -= cursorCost;
    cursors += 1;
    cursorCost = Math.ceil(cursorCost * 1.15);
  }
}

function drawFertilizerButton() {
  fill(coins >= fertilizerCost ? '#bc6c25' : '#ccc');
  rect(fertilizerButtonX, fertilizerButtonY, fertilizerButtonW, fertilizerButtonH, 14);
  fill('black');
  textSize(13);
  text(
    'Fertilizante (+10% pontos/click) | Nível: ' + fertilizerLevel + ' | ' + fertilizerCost + ' moedas',
    width / 2,
    fertilizerButtonY + fertilizerButtonH / 2
  );
}

function buyFertilizer() {
  if (coins >= fertilizerCost) {
    coins -= fertilizerCost;
    fertilizerLevel += 1;
    pointsPerClick = Math.max(1, Math.floor(pointsPerClick * 1.1));
    fertilizerCost = Math.ceil(fertilizerCost * 1.15);
  }
}

function drawKetchupFactoryButton() {
  fill(coins >= ketchupFactoryCost ? '#e63946' : '#ccc');
  rect(ketchupFactoryButtonX, ketchupFactoryButtonY, ketchupFactoryButtonW, ketchupFactoryButtonH, 14);
  fill('black');
  textSize(15);
  text(
    'Fábrica de Ketchup (+5 pts/s) | ' + ketchupFactoryCost + ' moedas',
    width / 2,
    ketchupFactoryButtonY + ketchupFactoryButtonH / 2
  );
}

function buyKetchupFactory() {
  if (coins >= ketchupFactoryCost) {
    coins -= ketchupFactoryCost;
    ketchupFactoryLevel += 1;
    ketchupFactoryCost = Math.ceil(ketchupFactoryCost * 1.15);
  }
}